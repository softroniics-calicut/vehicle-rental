-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2023 at 06:05 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vehicles_portal_provider`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_rental_vehicles`
--

CREATE TABLE `add_rental_vehicles` (
  `rental_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `vehicle_type` varchar(60) NOT NULL,
  `type_of_gear` varchar(30) NOT NULL,
  `color_of_vehicle` varchar(30) NOT NULL,
  `seats_of_vehicle` varchar(30) NOT NULL,
  `fuel_of_vehicle` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `RC` varchar(30) NOT NULL,
  `insurance` varchar(30) NOT NULL,
  `driving_licence` varchar(30) NOT NULL,
  `upload_photo` varchar(30) NOT NULL,
  `status` int(50) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_rental_vehicles`
--

INSERT INTO `add_rental_vehicles` (`rental_id`, `name`, `price`, `vehicle_type`, `type_of_gear`, `color_of_vehicle`, `seats_of_vehicle`, `fuel_of_vehicle`, `location`, `RC`, `insurance`, `driving_licence`, `upload_photo`, `status`) VALUES
(1, 'passion', '300', 'car', ' manual', ' red', '2', 'petrol', 'kollam', '1413663386.jpeg', '1903269141.jpeg', '1972039370.jpeg', '1548124929.jpeg', 1),
(2, 'Swift', '10000', 'car', ' manual', ' white', '5', 'cng', 'malappuram', '793602525.JPG', '1644510713.JPG', '559222559.JPG', '517585232.JPG', 1),
(3, 'apple', 'sdf', 'car', ' sdfgb', ' sdfb', 'sdfv', 'asdf', 'asdf', '488682335.jpg', '770490077.jpg', '1266288432.jpg', '816592272.jpg', 1),
(8, 'zen', '200', 'car', 'auto', 'red', '5', 'petrol', 'tirur', '123456789', '123456789', '09876543', '9876rgv ghjkv', 2),
(16, 'activa', '400', 'bike', 'automatic', 'white', '2', 'petrol', 'tanur', '123676543', '7655677653456', '765456654345', 'tfvcxrghgf', 2),
(17, '', '2', ' ', ' ', ' ', '', '', 'black', '1175696838.jpg', '2042586922.jpg', '987435438.jpg', '38442896.jpg', 0),
(18, 'alto', '2000', ' car', ' manual', ' white', '5', '', '', '116117897.jpg', '224768919.jpg', '46108150.jpg', '1570382630.jpg', 0),
(19, 'alto', '2000', ' car', ' manual', ' white', '5', '', '', '999850255.jpg', '1794141862.jpg', '1166783238.jpg', '1880993462.jpg', 0),
(20, 'alto', '300', ' car', ' manual', ' white', '4', 'petrol', '', '926602994.jpeg', '1723200885.jpeg', '639799601.jpeg', '2002743885.jpeg', 0),
(21, 'alto', '300', ' car', ' manual', ' white', '4', 'petrol', 'kollam', '1754504429.jpeg', '1472784396.jpeg', '1818862969.jpeg', '70642832.jpeg', 0),
(22, '3', 'user', 'adf', 'axsde', 'swe', 'sad', 'tyu', 'tyu', '', '', '', '', 0),
(23, '3', 'user', 'adf', 'axsde', 'swe', 'sad', 'tyu', 'tyu', '1345568576.jpg', '', '', '', 0),
(24, '3', 'user', 'adf', 'axsde', 'swe', 'sad', 'tyu', 'tyu', '311026577.jpg', '', '', '', 0),
(25, '3', 'user', 'adf', 'axsde', 'swe', 'sad', 'tyu', 'tyu', '621843433.jpg', '1043092130.jpeg', '1694122600.jpeg', '216357609.jpeg', 0),
(26, '3', 'user', 'adf', 'axsde', 'swe', 'sad', 'tyu', 'tyu', '293320768.jpg', '1244189986.jpeg', '1455891016.jpeg', '445995760.jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `add_transportation_vehicle`
--

CREATE TABLE `add_transportation_vehicle` (
  `transportation_id` int(11) NOT NULL,
  `vehicle` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `seats` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `RC` varchar(30) NOT NULL,
  `insurance` varchar(30) NOT NULL,
  `dl` varchar(30) NOT NULL,
  `upload_photo` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_transportation_vehicle`
--

INSERT INTO `add_transportation_vehicle` (`transportation_id`, `vehicle`, `price`, `seats`, `location`, `RC`, `insurance`, `dl`, `upload_photo`, `status`) VALUES
(1, ' auto', '30', '4', 'tirur', '2125099725.jpg', '52650056.jpg', '957321701.jpg', '536686747.jpg', '1'),
(2, ' bus', '2000', '55', 'tvm', '1504465615.jpg', '121907313.jpg', '2099279088.jpg', '948122037.jpg', '1'),
(3, 'bus', '200', '33', 'tirur', '123456765', '6543212345', '234567654', '123456543', '1'),
(4, 'bus', '200', '33', 'tirur', '123456765', '6543212345', '234567654', '123456543', '1'),
(5, ' taxi', '3000', '5', 'kochi', '574359923.jpg', '1232877710.jpg', '252392397.jpg', '1776844565.jpg', '1'),
(6, ' truck', '700', '3', 'kochi', '889660092.webp', '1939343348.webp', '350861799.webp', '1107465882.webp', '1');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feed_id` int(11) NOT NULL,
  `feedback` varchar(200) NOT NULL,
  `date` varchar(50) NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feed_id`, `feedback`, `date`, `time`) VALUES
(1, 'qswedfvberfc', '12/08/2023', '12.30 pm'),
(3, 'goood servivce', '12/08/2023', '11.pm'),
(4, 'goood servivce', '12/08/2023', '11.pm');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `log_id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`log_id`, `Email`, `Password`, `type`) VALUES
(1, 'abhi@12345', '1234', 'provider'),
(2, 'abhi@12345', '12345', 'provider'),
(3, 'anu@123', '1234', 'user'),
(4, 'ajil@1234', '54321', ''),
(5, 'ajil@1234', '54321', ''),
(6, 'admin@123', 'admin', 'admin'),
(7, 'admin@123', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notify_id` int(11) NOT NULL,
  `message` varchar(100) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`notify_id`, `message`, `date`, `time`) VALUES
(1, 'rthjyhg', '12/08/2023', 12),
(5, ' ', '', 0),
(6, '', '', 0),
(7, '', '', 0),
(8, 'xcfgbhn', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `amount` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment id`, `name`, `amount`, `date`, `time`) VALUES
(1, 'anu', '1000', '12/08/2023', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reg_id` int(11) NOT NULL,
  `login_id` int(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `Last_Name` varchar(30) NOT NULL,
  `street_address` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `Pin` int(10) NOT NULL,
  `Phone_number` varchar(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `login_id`, `first_name`, `Last_Name`, `street_address`, `city`, `state`, `Pin`, `Phone_number`, `Email`, `Password`) VALUES
(1, 1, 'kkk', '678888', '123456', 'dfghaj', 'dfghj', 0, 'cfghjk', 'abhi@12345', '1234'),
(2, 2, 'abhinav', 's', 'NMR', 'Tirur', 'Kerala', 676109, '9567112236', 'abhi@12345', '12345'),
(3, 3, 'anu', 's', 'NMR', 'Tirur', 'Kerala', 676109, '9567112236', 'anu@123', '1234'),
(4, 4, 'ajil', 'kk', 'nmr', 'thallasheri', 'kera ', 23567, '9876543210', 'ajil@1234', '54321'),
(5, 5, 'ajil', 'kk', 'nmr', 'thallasheri', 'kera ', 23567, '9876543210', 'ajil@1234', '54321');

-- --------------------------------------------------------

--
-- Table structure for table `rental_booking`
--

CREATE TABLE `rental_booking` (
  `booking_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone_no` int(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `last_date` varchar(30) NOT NULL,
  `Vehicle` varchar(30) NOT NULL,
  `select_proof` varchar(30) NOT NULL,
  `file` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transportation_booking`
--

CREATE TABLE `transportation_booking` (
  `booking_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone_no` int(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `from` varchar(30) NOT NULL,
  `destination` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  `vehicle` varchar(30) NOT NULL,
  `payment` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transportation_booking`
--

INSERT INTO `transportation_booking` (`booking_id`, `name`, `phone_no`, `address`, `from`, `destination`, `date`, `time`, `vehicle`, `payment`) VALUES
(1, 'anu', 1234567, 'sreebhavan', 'tirur', 'kollam', '05/05/2023', '7', 'taxi', '1000'),
(2, 'hhh', 0, '123456', 'dfghaj', 'dfghj', 'fghjk', 'cfghjk', 'dfghjk', 'dftgyhuik'),
(3, 'kkk', 0, '123456', 'dfghaj', 'dfghj', 'fghjk', 'cfghjk', 'dfghjk', 'dftgyhuik'),
(4, 'kkk', 0, '123456', 'dfghaj', 'dfghj', 'fghjk', 'cfghjk', 'dfghjk', 'dftgyhuik'),
(5, 'abhi ', 0, 'gshsksl', 'gdlao', 'gskod', '', '', '', ''),
(6, 'kkk', 678888, '123456', 'dfghaj', 'dfghj', 'fghjk', 'cfghjk', 'dfghjk', 'dftgyhuik'),
(7, 'abhi', 0, 'ahmmhzy', 'fjvt', 'yfgi', '', '', '', ''),
(8, 'abhi', 13457, 'ahmmhzy', 'fjvt', 'yfgi', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_rental_vehicles`
--
ALTER TABLE `add_rental_vehicles`
  ADD PRIMARY KEY (`rental_id`);

--
-- Indexes for table `add_transportation_vehicle`
--
ALTER TABLE `add_transportation_vehicle`
  ADD PRIMARY KEY (`transportation_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feed_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notify_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `rental_booking`
--
ALTER TABLE `rental_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `transportation_booking`
--
ALTER TABLE `transportation_booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_rental_vehicles`
--
ALTER TABLE `add_rental_vehicles`
  MODIFY `rental_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `add_transportation_vehicle`
--
ALTER TABLE `add_transportation_vehicle`
  MODIFY `transportation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notify_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rental_booking`
--
ALTER TABLE `rental_booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transportation_booking`
--
ALTER TABLE `transportation_booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
